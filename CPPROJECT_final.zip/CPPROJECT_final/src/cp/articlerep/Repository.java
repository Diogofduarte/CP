package cp.articlerep;

import java.util.HashSet;

import cp.articlerep.ds.Iterator;
import cp.articlerep.ds.LinkedList;
import cp.articlerep.ds.List;
import cp.articlerep.ds.Map;
import cp.articlerep.ds.HashTable;
import java.util.concurrent.locks.*;
import java.util.concurrent.locks.ReentrantReadWriteLock.WriteLock;

/**
 * @author Ricardo Dias
 */
public class Repository {

	private Map<String, List<Article>> byAuthor;
	private Map<String, List<Article>> byKeyword;
	private Map<Integer, Article> byArticleId;
	private ReentrantReadWriteLock lock = new ReentrantReadWriteLock();

	public Repository(int nkeys) {
		this.byAuthor = new HashTable<String, List<Article>>(40000);
		this.byKeyword = new HashTable<String, List<Article>>(40000);
		this.byArticleId = new HashTable<Integer, Article>(40000);
	}

	public boolean insertArticle(Article a) {

		//requisitar um write lock a table de ids bloqueando o id especifico que so e libertado no final caso ele nao exista
		byArticleId.wLock(a.getId());
		if (byArticleId.contains(a.getId())) {
			//O artigo ja existe
			byArticleId.wUnlock(a.getId());
			return false;
		}

		//colocar o artigo no mapa estando ele locked para esta thread
		byArticleId.put(a.getId(), a);
	
		Iterator<String> authors = a.getAuthors().iterator();
		//Percorrer todos os autores deste artigo bloqueando um a um a medida que vamos passando por eles e adicionando o artigo a sua lista de artigos
		while (authors.hasNext()) {
			String name = authors.next();
			//Dar lock para leitura deste autor, deste artigo. N�o dando de escrita pois varios pedidos de leitura podem ser feitos neste momento
			byAuthor.rLock(name);
			List<Article> ll = byAuthor.get(name);
			byAuthor.rUnlock(name);
			//Dar lock para escrita deste autor porque vai ter de ser feito uma alteracao a lista desse autor
			byAuthor.wLock(name);
			if (ll == null) {
				ll = new LinkedList<Article>();
				byAuthor.put(name, ll);
			}
			ll.add(a);
			//Dar release do lock deste autor para passar ao proximo
			byAuthor.wUnlock(name);
		}

		Iterator<String> keywords = a.getKeywords().iterator();
		//Iterar a lista de keywords do artigo para adicionar o mesmo a lista de artigos de cada keyword
		while (keywords.hasNext()) {
			String keyword = keywords.next();
			//Dar lock de leitura sobre esta keyword, proporcionando varias leituras sobre a table
			byKeyword.rLock(keyword);
			List<Article> ll = byKeyword.get(keyword);
			byKeyword.rUnlock(keyword);
			//Dar lock de escrita pois serao feitas alteracoes a table
			byKeyword.wLock(keyword);
			if (ll == null) {
				ll = new LinkedList<Article>();
				byKeyword.put(keyword, ll);
			}
			ll.add(a);
			//Dar unlock porque esta keyword ja foi tratada 
			byKeyword.wUnlock(keyword);

		}

		//Dar unlock a este artigo pois ja foi inserido na sua totalidade
		byArticleId.wUnlock(a.getId());
		return true;

	}

	public void removeArticle(int id) {

		//Dar lock no artigo especifico que so sera libertado depois de ser removido na totalidade ou nao existir
		byArticleId.wLock(id);
		Article a = byArticleId.get(id);

		if (a == null) {
			//o artigo nao existe
			byArticleId.wUnlock(id);
			return;
		}

		Iterator<String> keywords = a.getKeywords().iterator();
		//Iterar sobre todas as keywords deste artigo e remover o artigo das mesmas
		while (keywords.hasNext()) {
			String keyword = keywords.next();
			//Dar lock de leitura sobre esta keyword, proporcionando varias leituras sobre a table
			byKeyword.rLock(keyword);
			List<Article> ll = byKeyword.get(keyword);
			byKeyword.rUnlock(keyword);
			//Dar lock de escrita pois serao feitas alteracoes a table
			byKeyword.wLock(keyword);
			if (ll != null) {
				int pos = 0;
				Iterator<Article> it = ll.iterator();
				while (it.hasNext()) {
					Article toRem = it.next();
					if (toRem == a) {
						break;
					}
					pos++;
				}
				ll.remove(pos);
				it = ll.iterator();
				if (!it.hasNext()) { // checks if the list is empty
					byKeyword.remove(keyword);
				}
			}
			//Dar unlock porque esta keyword ja foi tratada
			byKeyword.wUnlock(keyword);
		}

		Iterator<String> authors = a.getAuthors().iterator();
		while (authors.hasNext()) {
			String name = authors.next();

			//Dar lock de leitura sobre este autor, proporcionando varias leituras sobre a table
			byAuthor.rLock(name);
			List<Article> ll = byAuthor.get(name);
			byAuthor.rUnlock(name);
			//Dar lock de escrita pois serao feitas alteracoes a table
			byAuthor.wLock(name);
			if (ll != null) {
				int pos = 0;
				Iterator<Article> it = ll.iterator();
				while (it.hasNext()) {
					Article toRem = it.next();
					if (toRem == a) {
						break;
					}
					pos++;
				}
				ll.remove(pos);
				it = ll.iterator();
				if (!it.hasNext()) { // checks if the list is empty
					byAuthor.remove(name);
				}
			}
			//Dar unlock porque este autor ja foi tratado
			byAuthor.wUnlock(name);
		}
		byArticleId.remove(id);
		//Dar unlock ao artigo especifico pois este ja foi tratado na totalidade
		byArticleId.wUnlock(id);
	}

	public List<Article> findArticleByAuthor(List<String> authors) {
		List<Article> res = new LinkedList<Article>();

		Iterator<String> it = authors.iterator();
		while (it.hasNext()) {
			String name = it.next();
			//Bloquear para leitura o autor procurado
			byAuthor.rLock(name);
			List<Article> as = byAuthor.get(name);
			if (as != null) {
				Iterator<Article> ait = as.iterator();
				while (ait.hasNext()) {
					Article a = ait.next();
					res.add(a);
				}
			}
			//Libertar este autor para procurar o proximo
			byAuthor.rUnlock(name);
		}
		return res;

	}

	public List<Article> findArticleByKeyword(List<String> keywords) {
		List<Article> res = new LinkedList<Article>();

		Iterator<String> it = keywords.iterator();
		while (it.hasNext()) {
			String keyword = it.next();
			byKeyword.rLock(keyword);
			List<Article> as = byKeyword.get(keyword);
			if (as != null) {
				Iterator<Article> ait = as.iterator();
				while (ait.hasNext()) {
					Article a = ait.next();
					res.add(a);
				}
			}
			byKeyword.rUnlock(keyword);
		}

		return res;

	}

	/**
	 * This method is supposed to be executed with no concurrent thread
	 * accessing the repository.
	 * 
	 */
	public boolean validate() {

		HashSet<Integer> articleIds = new HashSet<Integer>();
		int articleCount = 0;

		Iterator<Article> aIt = byArticleId.values();
		while (aIt.hasNext()) {
			Article a = aIt.next();

			articleIds.add(a.getId());
			articleCount++;

			// check the authors consistency
			Iterator<String> authIt = a.getAuthors().iterator();
			while (authIt.hasNext()) {
				String name = authIt.next();
				if (!searchAuthorArticle(a, name)) {
					return false;
				}
			}

			// check the keywords consistency
			Iterator<String> keyIt = a.getKeywords().iterator();
			while (keyIt.hasNext()) {
				String keyword = keyIt.next();
				if (!searchKeywordArticle(a, keyword)) {
					return false;
				}
			}
		}
		// Consistencia dos autores
		Iterator<List<Article>> auIt = byAuthor.values();
		while (auIt.hasNext()) {
			List<Article> authArticles = auIt.next();
			Iterator<Article> artic = authArticles.iterator();
			while (artic.hasNext()) {
				if (!byArticleId.contains(artic.next().getId())) {
					System.out.println("os autores tem artigos que nao existem nos artigos");
					return false;
				}
			}
		}

		Iterator<List<Article>> keywIt = byKeyword.values();
		while (keywIt.hasNext()) {
			List<Article> keyArticles = keywIt.next();
			Iterator<Article> art = keyArticles.iterator();
			while (art.hasNext()) {
				if (!byArticleId.contains(art.next().getId())) {
					System.out.println("as keywords tem artigos que nao existem nos artigos");
					return false;
				}
			}
		}

		return articleCount == articleIds.size();
	}

	private boolean searchAuthorArticle(Article a, String author) {

		List<Article> ll = byAuthor.get(author);
		if (ll != null) {
			Iterator<Article> it = ll.iterator();
			while (it.hasNext()) {
				if (it.next() == a) {
					return true;
				}
			}
		}
		return false;

	}

	private boolean searchKeywordArticle(Article a, String keyword) {

		List<Article> ll = byKeyword.get(keyword);
		if (ll != null) {
			Iterator<Article> it = ll.iterator();
			while (it.hasNext()) {
				if (it.next() == a) {
					return true;
				}
			}
		}
		return false;

	}

}
