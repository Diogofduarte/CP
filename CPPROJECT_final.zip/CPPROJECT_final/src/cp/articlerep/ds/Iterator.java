package cp.articlerep.ds;

public interface Iterator<V> {
	
	public boolean hasNext();
	public V next();

}
